import pandas as pd
import numpy as np

# Define the structure of the dataset
structure = {'column1': np.random.rand(100), 'column2': np.random.rand(100), 'column3': np.random.rand(100)}

# Create a DataFrame
df = pd.DataFrame(structure)

# Save the DataFrame to a CSV file
df.to_csv('synthetic_dataset.csv', index=False)