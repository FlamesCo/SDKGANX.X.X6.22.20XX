#!/bin/sh

# This is the start of the encryption script
# Function for AES encryption
function aes_encryption() {
  # TODO: Implement AES encryption
}

# Function for RSA encryption
function rsa_encryption() {
  # TODO: Implement RSA encryption
}

# Function for PGP encryption
function pgp_encryption() {
  # TODO: Implement PGP encryption
}
# Function for AES encryption
function aes_encryption() {
  # Encrypt the file
  openssl enc -aes-256-cbc -in $1 -out $1.enc

  # Decrypt the file
  openssl enc -d -aes-256-cbc -in $1.enc -out $1.dec
}