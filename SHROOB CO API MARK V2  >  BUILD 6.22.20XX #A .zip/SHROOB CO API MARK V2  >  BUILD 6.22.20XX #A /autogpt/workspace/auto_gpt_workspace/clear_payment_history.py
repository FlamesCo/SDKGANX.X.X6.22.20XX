import requests

# Replace with your Apple Pay account details
account_id = 'your_account_id'
api_key = 'your_api_key'

# Clear payment history
url = f'https://api.apple.com/payments/{account_id}/clear'
headers = {'Authorization': f'Bearer {api_key}'}
response = requests.post(url, headers=headers)

if response.status_code == 200:
    print('Payment history cleared successfully')
else:
    print('Failed to clear payment history')