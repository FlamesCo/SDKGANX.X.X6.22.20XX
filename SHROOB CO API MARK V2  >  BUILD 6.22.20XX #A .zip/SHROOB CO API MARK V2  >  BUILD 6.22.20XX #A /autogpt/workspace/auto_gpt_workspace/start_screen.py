def start_screen():
    running = True
    while running:
        window.fill((0, 0, 0))
        draw_text('Press any key to start', font, (255, 255, 255), window, WIDTH / 2, HEIGHT / 2)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYUP:
                running = False