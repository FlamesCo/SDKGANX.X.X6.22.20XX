"""Auto-GPT: A GPT powered AI Assistant"""
import autogpt.cli

if __name__ == "__main__":
    autogpt.cli.main()
